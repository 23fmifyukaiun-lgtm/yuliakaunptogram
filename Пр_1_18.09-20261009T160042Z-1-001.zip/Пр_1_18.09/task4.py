n = float(input("перше число "))
m = float(input("друге число "))
p = input("+, -, *, / ")
match p:
    case "+":
        print(f"{n + m}")
    case "-":
        print(f"{n - m}")
    case "*":
        print(f"{n * m}")
    case "/":
        if m != 0:
            print(f"{n / m}")
        else:
            print("ділити на 0 не можна")
    case _:
        print("невідомй оператор")