def generate_ticket(passenger, destination):
    s = random.randint(1, 50)
    d = datetime.datetime.now().date()
    return f"Квиток: {passenger}, Напрямок: {destination}, Місце: {s}, Дата: {d}"