#Перевірка повноліття
def is_adult(birth_year):
    y = datetime.datetime.now().year
    return (y - birth_year) >= 18