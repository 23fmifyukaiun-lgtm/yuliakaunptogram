# контроль багажу в аеропорту
def check_baggage(*weights):
    s = 0
    for w in weights:
        s += w
    return s <= 50