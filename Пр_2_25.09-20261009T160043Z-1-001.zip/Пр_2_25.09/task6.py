pasword = input("введіть пароль ")
a = False
b = False
c = False
for x in pasword:
    if x.islower():
        a = True
    elif x.isupper():
        b = True
    elif x.isdigit():
        c = True
if a and b and c:
    print("пароль безпечний")
else:
    print("пароль небезпечний!")