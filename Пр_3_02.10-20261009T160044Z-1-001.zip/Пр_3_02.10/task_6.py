#Генератор знижки
def get_daily_discount():
    x = random.randint(1, 100)
    if x <= 10:
        return "знижка: 50%"
    elif x <= 30:
        return "знижка: 20%"
    else:
        return "знижка: 5%"