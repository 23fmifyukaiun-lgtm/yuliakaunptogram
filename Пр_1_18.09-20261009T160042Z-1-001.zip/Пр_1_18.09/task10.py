a = [36, 72, 90, 108]

for i in range(len(a)):
    a[i] = a[i] / 3.6

print(a)