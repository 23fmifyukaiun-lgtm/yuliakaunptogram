p = 1.0
for n in range(1, 10001):
    p *= (4 * (n ** 2)) / (4 * (n ** 2) - 1)
if n % 100 == 0:
    pi = 2 * p
    print(f"N = {n}: pi ≈ {pi}")