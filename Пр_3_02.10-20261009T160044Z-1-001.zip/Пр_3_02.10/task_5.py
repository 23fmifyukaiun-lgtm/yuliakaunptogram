#Призначення модератора
def assign_moderator(a):
    return random.choice(a)