#Дійні корені квадратного р-ння#
a = float(input("коефіцієнт a "))
b = float(input("коефіцієнт b "))
c = float(input("коефіцієнт c "))
D = b**2 - 4 * a * c
if D > 0:
    x1 = (-b + D**0.5) / (2 * a)
    x2 = (-b - D**0.5) / (2 * a)
    vidpov = (x1, x2)
elif D == 0:
    x = -b / (2 * a)
    vidpov = (x,)
else:
    vidpov = ()
print(f"корені рівняння: {vidpov}")