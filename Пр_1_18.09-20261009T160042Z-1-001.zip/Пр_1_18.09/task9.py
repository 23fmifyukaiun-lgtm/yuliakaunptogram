n = [8, 11, 7, 10]
n.remove(7)
n.append(12)
n.sort(reverse=True)

print(n)