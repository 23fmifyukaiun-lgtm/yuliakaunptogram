n = int(input("введіть кількість рядків n "))
k = int(input("введіть кількість стовпців k "))
m = []
print("введіть елементи матриці (через пробіл)")
for i in range(n):
    r = [float(x) for x in input(f"рядок {i + 1}: ").split()]
    m.append(r)
sumi = []
for r in m:
    sumi.append(sum(r))
csums = []
for j in range(k):
    csum = 0
    for r in sumi:
        csum += r
    csums.append(csum)
print(f"Суми рядків: {sumi}")
print(f"Суми стовпців: {csum}")

