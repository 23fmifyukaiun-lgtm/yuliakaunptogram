s = input("Введіть рядок тексту: ")
s_up = s.upper()
counts = {}
for ch in s_up:
    if ch.isalpha():
        counts[ch] = s_up.count(ch)
res_letter = ""
max_c = 0
for key, val in counts.items():
    if val > max_c:
        max_c = val
        res_letter = key
print(f"Найчастіша літера: {res_letter}")