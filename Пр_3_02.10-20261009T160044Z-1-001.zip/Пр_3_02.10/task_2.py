# Профіль користувача
def create_user(username, role="user", status="active"):
    return f"Користувач: {username}, Роль: {role}, Статус: {status}"

print(create_user("Анна"))
print(create_user("Максим", role="admin"))