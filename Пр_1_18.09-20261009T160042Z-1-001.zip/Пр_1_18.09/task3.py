x = int(input("x "))
y = int(input("y "))
if x == 0 and y == 0:
    print("точка у поч.коорд.")
elif x == 0 or y == 0:
    print("точка на осі")
if x > 0 and y > 0:
    print("точка у 1 чверті")
elif x < 0 and y > 0:
    print("точка в 2 чверті")
elif x < 0 and y < 0:
    print("точка в 3 чверті")
elif x > 0 and y < 0:
    print("точка у 4 чверті")
