# Розрахунок зарплати
def calculate_salary(a, b):
    return a * b