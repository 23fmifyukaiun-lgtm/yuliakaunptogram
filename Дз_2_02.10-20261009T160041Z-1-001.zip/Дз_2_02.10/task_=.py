import math

def calculate_trip_cost(distance, fuel_consumption, fuel_price):
    a = distance / 100 * fuel_consumption
    b = a * fuel_price
    return math.ceil(b)