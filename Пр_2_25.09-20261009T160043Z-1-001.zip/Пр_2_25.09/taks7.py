m = int(input("введіть кількість вимірювань m "))
a = []
for i in range(m):
    n = float(input(f"введіть число {i + 1}: "))
    a.append(n)
n = sum(a) / m
d = 0
for x in a:
    d += (x - n) ** 2
dd = d / (m - 1)
vidh = dd ** 0.5
print(f"Середнє арифметичне {n}")
print(f"Дисперсія {dd}")
print(f"Стандартне відхилення {vidh}")