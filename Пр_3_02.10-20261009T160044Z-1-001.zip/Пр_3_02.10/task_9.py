#Аналізатор розширень файлів
def get_file_type(extension):
    d = {
        ".jpg": "Зображення",
        ".mp3": "Аудіо",
        ".py": "Скрипт Python"
    }
    return d.get(extension, "Невідомий формат")