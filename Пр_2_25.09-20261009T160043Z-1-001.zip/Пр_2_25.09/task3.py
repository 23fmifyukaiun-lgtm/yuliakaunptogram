x = float(input("значення x "))
if -5 < x < 5:
    fx = 2 * (x ** 2) + 3 * x - 1
else:
    fx = 0
print(f"значення функції f(x) = {fx}")