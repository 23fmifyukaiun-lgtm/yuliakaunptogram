contacts = {}
while True:
    comanda = input("введіть команду ")
    if comanda == "add":
        name = input("введіть ім'я ")
        number = input("введіть номер ")
        contacts[name] = number
        print("контакт додано до телефонної книги :) ")
    elif comanda == "delete":
        name = input("введіть ім'я ")
        if name in contacts:
            contacts.pop(name)
            print("ви видалили контакт з телефонної книги :( ")
        else:
            print("не існує такого контакту :( ")
    elif comanda == "search":
        name = input("введіть ім'я ")
        result = contacts.get(name, "не знайдено")
        print("результат", result)
    elif comanda == "show":
        for k, v in contacts.items():
            print(k, "-", v)
    elif comanda == "exit":
        print("вийти з програми :( ")
        break
    else:
        print("невідома команда, введіть ще раз :3 ")