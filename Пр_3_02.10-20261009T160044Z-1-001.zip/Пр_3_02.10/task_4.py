#Пошук найдловшого слова
def find_longest(*words):
    res = ""
    for w in words:
        if len(w) > len(res):
            res = w
    return res