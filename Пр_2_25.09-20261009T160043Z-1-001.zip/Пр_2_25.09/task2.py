a = float(input("Введіть катет a: "))
b = float(input("Введіть катет b: "))
c = (a**2 + b**2) ** 0.5
pl = 0.5 * a * b
p = a + b + c
print(f"гіпотенуза: {c}")
print(f"площа: {pl}")
print(f"периметр: {p}")